Iconset: Files vol.1 (https://www.iconfinder.com/iconsets/files-vol-1-3)
Author: Marta Konyk (https://www.iconfinder.com/MartaKonyk)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2022-07-15