Iconset: Files vol.2 (https://www.iconfinder.com/iconsets/files-vol-2-2)
Author: Marta Konyk (https://www.iconfinder.com/MartaKonyk)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2022-07-15